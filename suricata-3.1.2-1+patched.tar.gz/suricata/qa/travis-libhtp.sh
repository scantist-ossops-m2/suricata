#!/bin/sh
set -ex
git clone https://github.com/ironbee/libhtp -b 0.5.x
