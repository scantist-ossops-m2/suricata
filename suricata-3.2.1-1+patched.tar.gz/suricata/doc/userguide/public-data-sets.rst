Public Data Sets
================

Collections of pcaps for testing, profiling.

DARPA sets: http://www.ll.mit.edu/mission/communications/cyber/CSTcorpora/ideval/data/

MAWI sets (pkt headers only, no payloads): http://mawi.wide.ad.jp/mawi/samplepoint-F/2012/

MACCDC: http://www.netresec.com/?page=MACCDC

Netresec: http://www.netresec.com/?page=PcapFiles

Wireshark: https://wiki.wireshark.org/SampleCaptures

Security Onion collection: https://github.com/security-onion-solutions/security-onion/wiki/Pcaps
