Output
======

Introduction
------------

Extending Suricata's alert and event output.
